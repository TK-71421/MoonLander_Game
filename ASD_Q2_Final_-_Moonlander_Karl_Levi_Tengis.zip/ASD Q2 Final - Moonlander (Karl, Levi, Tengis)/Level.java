package moonlander;
import javafx.scene.Scene;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Level extends Scene {
	public Level (Rectangle[] scrls, VBox[] data) {
		super(new Pane(scrls[0], scrls[1], scrls[2], scrls[3], LanderGUIFX.iv, data[0], data[1], LanderGUIFX.ground),
				1920, 1010);
		LanderGUIFX.iv.relocate(150, 100);
		LanderGUIFX.iv.setRotate(-90);
		LanderGUIFX.ground.relocate(-2560, 490);
		LanderGUIFX.lander.setVerVel(0);
		LanderGUIFX.lander.setHorVel(80);
		LanderGUIFX.lander.setLanded(false);
		LanderGUIFX.landerImg.setImage(Lander.noThrust);
		LanderGUIFX.wFlag = false;
		LanderGUIFX.aFlag = false;
		LanderGUIFX.dFlag = false;
		LanderGUIFX.upFlag = false;
		LanderGUIFX.downFlag = false;
		LanderGUIFX.rightFlag = false;
		LanderGUIFX.leftFlag = false;
		LanderGUIFX.shiftFlag = false;
		scrls[0].relocate(0, 0);
		scrls[1].relocate(0, 710);
		scrls[2].relocate(0, 0);
		scrls[3].relocate(1620, 0);
		data[0].relocate(20, 20);
		data[1].relocate(1700, 20);
		((Pane)getRoot()).setBackground(new Background(new BackgroundFill(Color.grayRgb(42), null, null)));
	}
}
