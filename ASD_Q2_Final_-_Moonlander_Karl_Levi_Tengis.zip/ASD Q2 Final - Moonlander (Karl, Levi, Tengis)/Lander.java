package moonlander;
import javafx.scene.image.Image;

/**
 * hitbox: 24px wide by 24px tall (flame doesnt have hitbox)
 */
public class Lander {
	public static Image noThrust = new Image("file:///C:/Users/Public/Pictures/noThrust.png");
	public static Image thrust1 = new Image("file:///C:/Users/Public/Pictures/thrust1.png");
	public static Image thrust2 = new Image("file:///C:/Users/Public/Pictures/thrust2.png");
	public static Image thrust3 = new Image("file:///C:/Users/Public/Pictures/thrust3.png");
	public static Image thrust4 = new Image("file:///C:/Users/Public/Pictures/thrust4.png");
	private double verVel; // positive is down
	private double horVel; // positive is right
	private int fuel;
	private boolean isLanded;
	private boolean isDestroyed;
	public Lander () {
		verVel = 0;
		horVel = 80;
		fuel = 1000;
		isLanded = false;
		isDestroyed = false;
	}
	public double getVerVel () {
		return verVel;
	}
	public void setVerVel (double d) {
		verVel = d;
	}
	public double getHorVel () {
		return horVel;
	}
	public void setHorVel (double horVel) {
		this.horVel = horVel;
	}
	public int getFuel () {
		return fuel;
	}
	public void setFuel (int fuel) {
		this.fuel = fuel;
	}
	public boolean isDestroyed () {
		return isDestroyed;
	}
	public void setDestroyed (boolean isDestroyed) {
		this.isDestroyed = isDestroyed;
	}
	public boolean isLanded () {
		return isLanded;
	}
	public void setLanded (boolean isLanded) {
		this.isLanded = isLanded;
	}
}
