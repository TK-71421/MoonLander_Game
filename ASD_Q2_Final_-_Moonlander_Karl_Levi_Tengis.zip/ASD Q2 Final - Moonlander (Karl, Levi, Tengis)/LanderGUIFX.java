package moonlander;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Optional;
import java.util.Random;
import java.util.Scanner;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Polyline;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;
import javafx.scene.shape.StrokeLineCap;
import javafx.scene.shape.StrokeLineJoin;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class LanderGUIFX extends Application {
	public static final long REFRESH_INTERVAL_MS = 17;
	public static final double HORIZONTAL_WIND_RESISTENCE = 0.9999;
	public static final double GRAVITY = 0.1;
	public static final double THRUST = 0.25;
	public static final Button gameEnder = new Button();
	public static final ImageView logo = new ImageView(new Image("file:///C:/Users/Public/Pictures/Moon.jpg"));
	public static String[] messages = new String[] {
			"Welcome to Moonlander!",
			"Created by Levi, Tengis, and Karl",
			"Press the Space Bar to begin playing",
			"You can't land here! You lifen't and your ship EXPLODED!!!",
			"You tried to land too fast on a landing zone and EXPLODED!!!",
			"You tried to land at a bad angle on a landing zone and EXPLODED!!!",
			"You landed safely!"};
	public static int[] terrain = new int[410];
	public static int roundNum = 1;
	public static long startTime;
	public static long roundStartTime;
	public static long totalTime = 0;
	public static long startPause;
	public static double score = 0.0;
	private final Object redrawLock = new Object();
	private volatile boolean keepGoing = true;
	private int frameNum = 0;
	static boolean wFlag = false;
	static boolean aFlag = false;
	static boolean dFlag = false;
	static boolean shiftFlag = false;
	static boolean upFlag = false;
	static boolean downFlag = false;
	static boolean leftFlag = false;
	static boolean rightFlag = false;
	static boolean wrapLeft = false;
	static boolean wrapRight = false;
	static double altitude = 910;
	static double xPos = 0;
	static double[] points;
	static double[] landerData = new double[] {0, 0, 0};
	static Text scoreLbl = new Text("Score:   0000");
	static Text timeLbl = new Text("Time:    00:00");
	static Text fuelLbl = new Text("Fuel:    1000");
	static Text altLbl = new Text("Altitude:           00000");
	static Text verVelLbl = new Text("Vertical Speed:      0000");
	static Text horVelLbl = new Text("Horizontal Speed:    0000");
	static Text angleLbl = new Text("Angle:            00.00");
	static WritableImage wi;
	static Rectangle[] zones;
	static Rectangle[] land;
	public static Lander lander;
	public Scene scn;
	private Rectangle scrlUp;
	private Rectangle scrlDown;
	private Rectangle scrlLeft;
	private Rectangle scrlRight;
	public static ImageView landerImg;
	private static Rectangle bb;
	public static StackPane iv;
	public static Polyline groundLine;
	public static Group ground;
	static Shape sh;
	static Color transparent = new Color(0, 0, 0, 0);
	public Shape[] nodes = new Shape[] {groundLine};
	public static void readTerrain (double[] arr, String fileName) {
		File temp = new File(fileName);// "C:\\Users\\Public\\Documents\\terrainPoints.txt"
		try {
			Scanner fr = new Scanner(temp);
			for (int x = 0; x < arr.length; x++) {
				double point = fr.nextDouble();
				arr[x] = point;
			}
			fr.close();
		} catch (IOException ex) {
			System.out.println(ex);
		}
		points = arr.clone();
	}
	public static void readLandingZones (double[] arr) { // 48px landing pad, 12 array slots
		System.out.println("landin");
		zones = new Rectangle[20];
		int counter = 0;
		double oldY = arr[1];
		for (int x = 0; x < (arr.length - 48); x += 2)
			for (int y = 1; y < 12; y++) {
				if (arr[x + 1] != arr[x + 1 + +(2 * y)])
					break;
				if ((y == 11) && (counter < 20)) {
					System.out.println("Added rect #" + counter);
					zones[counter] = new Rectangle(arr[x] - 2, arr[x + 1] - 1, 46, 2);
					counter++;
				}
			}
	}
	@Override
	public void start (final Stage stg) throws InterruptedException {
		final Task<Void> endGame = new Task<Void>() {
			@Override
			protected Void call () throws Exception {
				if (isCancelled())
					return null;
				Platform.runLater(new Runnable() {
					@Override
					public void run () {
						gameEnder.fire();
					}
				});
				return null;
			}
		};
		ground = new Group();
		Image i1 = new Image("file:///C:/Users/Public/Pictures/MoonSqr.jpg", 16, 16, true, false);
		Image i2 = new Image("file:///C:/Users/Public/Pictures/MoonSqr.jpg", 32, 32, true, false);
		Image i3 = new Image("file:///C:/Users/Public/Pictures/MoonSqr.jpg", 48, 48, true, false);
		Image i4 = new Image("file:///C:/Users/Public/Pictures/MoonSqr.jpg", 64, 64, true, false);
		Image i5 = new Image("file:///C:/Users/Public/Pictures/MoonSqr.jpg", 96, 96, true, false);
		stg.getIcons().addAll(i1, i2, i3, i4, i5);
		double[] arr = new double[640];
		LanderGUIFX.readTerrain(arr, "C:\\Users\\Public\\Documents\\MountainTerrain.txt");
		groundLine = new Polyline();
		groundLine.setStroke(Color.WHITE);
		for (int x = 0; x < arr.length; x++)
			if ((x % 2) == 0)
				arr[x] -= 2560; // width of each run is 1280
			else if ((x % 2) == 1)
				arr[x] += 290;
		for (int x = 0; x < 4; x++) {
			for (int y = 0; y < arr.length; y += 2)
				groundLine.getPoints().addAll(arr[y], arr[y + 1]);
			for (int y = 0; y < arr.length; y++)
				if ((y % 2) == 0)
					arr[y] += 1280;
		}
		double[] points = new double[2560];
		for (int x = 0; x < groundLine.getPoints().size(); x++)
			points[x] = groundLine.getPoints().get(x);
		LanderGUIFX.readLandingZones(points);
		ground.getChildren().addAll(groundLine);
		scrlUp = new Rectangle(1920, 100);
		scrlDown = new Rectangle(1920, 300);
		scrlLeft = new Rectangle(300, 1010);
		scrlRight = new Rectangle(300, 1010);
		scrlUp.setStroke(transparent);
		scrlDown.setStroke(transparent);
		scrlLeft.setStroke(transparent);
		scrlRight.setStroke(transparent);
		scrlUp.setStrokeWidth(2);
		scrlDown.setStrokeWidth(2);
		scrlLeft.setStrokeWidth(2);
		scrlRight.setStrokeWidth(2);
		scrlUp.setFill(transparent);
		scrlDown.setFill(transparent);
		scrlLeft.setFill(transparent);
		scrlRight.setFill(transparent);
		scrlUp.setLayoutX(0 - scrlUp.getLayoutBounds().getMinX());
		scrlUp.setLayoutY(0 - scrlUp.getLayoutBounds().getMinY());
		scrlDown.setLayoutX(0 - scrlUp.getLayoutBounds().getMinX());
		scrlDown.setLayoutY(710 - scrlUp.getLayoutBounds().getMinY());
		scrlLeft.setLayoutX(0 - scrlUp.getLayoutBounds().getMinX());
		scrlLeft.setLayoutY(0 - scrlUp.getLayoutBounds().getMinY());
		scrlRight.setLayoutX(1620 - scrlUp.getLayoutBounds().getMinX());
		scrlRight.setLayoutY(0 - scrlUp.getLayoutBounds().getMinY());
		Font font = new Font("Courier New", 12);
		scoreLbl.setFont(font);
		scoreLbl.setStroke(Color.WHITE);
		timeLbl.setFont(font);
		timeLbl.setStroke(Color.WHITE);
		fuelLbl.setFont(font);
		fuelLbl.setStroke(Color.WHITE);
		altLbl.setFont(font);
		altLbl.setStroke(Color.WHITE);
		verVelLbl.setFont(font);
		verVelLbl.setStroke(Color.WHITE);
		horVelLbl.setFont(font);
		horVelLbl.setStroke(Color.WHITE);
		angleLbl.setFont(font);
		angleLbl.setStroke(Color.WHITE);
		logo.setFitWidth(128);
		logo.setPreserveRatio(true);
		lander = new Lander();
		landerImg = new ImageView(Lander.noThrust);
		bb = new Rectangle(24, 24);
		bb.setLayoutX(bb.getLayoutBounds().getMinX() - 0);
		bb.setLayoutY(bb.getLayoutBounds().getMinY() - 36);
		bb.setFill(transparent);
		bb.setStroke(transparent);
		bb.setStrokeWidth(1.0);
		iv = new StackPane(bb, landerImg);
		iv.setPrefSize(24, 96);
		VBox leftData = new VBox(8);
		VBox rightData = new VBox(8);
		// pn = new Pane(scrlUp, scrlDown, scrlLeft, scrlRight, iv, leftData, rightData, ground);
		for (int x = 0; x < zones.length; x++) {
			ground.getChildren().addAll(zones[x]);
			zones[x].setArcWidth(10);
			zones[x].setArcHeight(4);
			zones[x].setStrokeLineJoin(StrokeLineJoin.ROUND);
			zones[x].setStrokeLineCap(StrokeLineCap.ROUND);
			zones[x].setStroke(Color.DEEPSKYBLUE);
			zones[x].setStrokeWidth(2);
			zones[x].setFill(transparent);
			zones[x].relocate(zones[x].getX(), zones[x].getY() - 1);
			System.out.println("Loaded landing zone: " + x);
		}
		leftData.getChildren().addAll(scoreLbl, timeLbl, fuelLbl);
		leftData.setPrefSize(120, 52);
		leftData.setLayoutX(20 - leftData.getLayoutBounds().getMinX());
		leftData.setLayoutY(20 - leftData.getLayoutBounds().getMinY());
		rightData.setPrefSize(200, 52);
		rightData.setLayoutX(1700 - rightData.getLayoutBounds().getMinX());
		rightData.setLayoutY(20 - rightData.getLayoutBounds().getMinY());
		rightData.getChildren().addAll(altLbl, verVelLbl, horVelLbl, angleLbl);
		iv.setLayoutX(150 - iv.getLayoutBounds().getMinX());
		iv.setLayoutY(100 - iv.getLayoutBounds().getMinX());
		iv.setRotate(-90);
		ground.setLayoutX(-2560 - ground.getLayoutBounds().getMinX());
		ground.setLayoutY(490 - ground.getLayoutBounds().getMinY());
		final Rectangle[] scrolls = new Rectangle[] {scrlUp, scrlDown, scrlLeft, scrlRight};
		final VBox[] data = new VBox[] {leftData, rightData};
		scn = new Level(scrolls, data);
		scn.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle (KeyEvent event) {
				if (event.getCode().equals(KeyCode.W) && (lander.getFuel() > 0))
					wFlag = true;
				if (event.getCode().equals(KeyCode.A))
					aFlag = true;
				if (event.getCode().equals(KeyCode.D))
					dFlag = true;
				if (event.isShiftDown())
					shiftFlag = true;
				if (!event.isShiftDown())
					shiftFlag = false;
			}
		});
		scn.setOnKeyReleased(new EventHandler<KeyEvent>() {
			@Override
			public void handle (KeyEvent event) {
				if (event.getCode().equals(KeyCode.W))
					wFlag = false;
				if (event.getCode().equals(KeyCode.A))
					aFlag = false;
				if (event.getCode().equals(KeyCode.D))
					dFlag = false;
			}
		});
		stg.setScene(scn);
		stg.setTitle("Moonlander");
		stg.sizeToScene();
		stg.show();
		gameEnder.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle (ActionEvent event) {
				roundNum++;
				WritableImage wi = scn.snapshot(null);
				HBox hb = new HBox(180);
				VBox vb = new VBox(20);
				Pane pain = new Pane();
				Button quit = new Button("Continue");
				Button scoringInfo = new Button("Scoring Info");
				// Button cont = new Button("Continue");
				Text[] fail = new Text[] {
						new Text("You just destroyed a 200 megabuck lander"),
						new Text("Ouch. That looked like it hurt. (the ship, not you. duh.)"),
						new Text("That poor rocket. What did it ever do to you?"),
						new Text("Moonlander:\nYou: I'm boutta end this man's whole career")
				};
				Text[] success = new Text[] {
						new Text("I didn't think you had it in you!"),
						new Text("Good work. Time to gather samples!"),
						new Text("O2 is expensive. Make haste."),
						new Text("I've seen better landings.")};
				Random randy = new Random();
				Text info;
				if ((landerData[0] > 16) && lander.isLanded())// vervel
					info = new Text(messages[4]);
				else if ((Math.abs(landerData[2]) > 8) && lander.isLanded())// angle
					info = new Text(messages[5]);
				else if ((Math.abs(landerData[1]) > 7.5) && lander.isLanded())// horvel
					info = new Text(messages[4]);
				else if (!lander.isLanded())// checks if on landing pad
					info = new Text(messages[3]);
				else
					info = new Text(messages[6]);
				Text txt = null;
				if (lander.isLanded() && info.getText().equals(messages[6])) {// success
					int a = randy.nextInt(success.length);
					if (a == 0)
						txt = success[0];
					else if (a == 1)
						txt = success[1];
					else if (a == 2)
						txt = success[2];
					else if (a == 3)
						txt = success[3];
				} else {// isLanded == false OR isLanded == true && info.equals == false
					int a = randy.nextInt(fail.length);
					if (a == 0)
						txt = fail[0];
					else if (a == 1)
						txt = fail[1];
					else if (a == 2)
						txt = fail[2];
					else if (a == 3)
						txt = fail[3];
				}
				hb.getChildren().addAll(quit, scoringInfo);
				// if (!lander.isLanded())
				// hb.getChildren().addAll(quit);
				hb.setAlignment(Pos.CENTER);
				vb.getChildren().addAll(info, txt, hb);
				pain.getChildren().addAll(vb);
				pain.setPrefSize(1920, 1010);
				vb.setPrefSize(450, 180);
				vb.relocate(735, 415);
				vb.setAlignment(Pos.CENTER);
				vb.setBackground(new Background(new BackgroundFill(Color.GREY, new CornerRadii(10), null)));
				pain.setBackground(new Background(new BackgroundImage(wi, null, null, null, null)));
				Scene between = new Scene(pain, 1920, 1010);
				stg.setScene(between);
				scoringInfo.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle (ActionEvent event) {
						DecimalFormat df1 = new DecimalFormat("000.00");
						DecimalFormat df2 = new DecimalFormat("00.00");
						String results = "";
						double angle = Math.abs(landerData[2]);
						double vVel = Math.abs(landerData[0]);
						double hVel = Math.abs(landerData[1]);
						double scr = 200;// (lander.getFuel() / 2) + 100
						results += "Starting Score: " + scr + " pts\n";
						if (!lander.isLanded()) {// idk why but this "not" is needed
							scr = 0;
							results += "You didn't land in a Landing Zone dummy;\n No Points\n";
						}
						results += "Angle: " + df2.format(landerData[2]) + " degrees\n";
						results += "Horizontal Velocity: " + df1.format(hVel) + " m/s\n";
						results += "Vertical Velocity: " + df1.format(vVel) + " m/s\n";
						// double sub = angle * 1.5 * hVel * 2 * lander.getVerVel();
						if ((angle > 5) && (angle < 8)) {
							results += "Angle Penalty: -" + Double.toString(scr * 0.5) + " pts\n";
							scr *= 0.5;
						} else if (angle >= 8) {
							results += "Angle too steep; No Points\n";
							scr *= 0;
						}
						if ((vVel >= 10) && (vVel < 16)) {
							results += "Vertical Velocity penalty: -" + Double.toString(scr * 0.5) + " pts\n";
							scr *= 0.5;
						} else if (vVel >= 16) {
							results += "Vertical Velocity too high; No Points\n";
							scr *= 0;
						}
						if (hVel > 7.5) {
							results += "Horizontal Velocity too high; No Points\n";
							scr *= 0;
						} else if ((hVel > 4) && (hVel <= 7.5))
							results += "Horizontal Velocity Penalty: -" + Double.toString(scr * 0.5) + " pts\n";
						results += "Your Score: " + Double.toString(scr) + "pts\n";
						ButtonType close = new ButtonType("Close", ButtonData.CANCEL_CLOSE);
						Alert dc = new Alert(AlertType.INFORMATION, results, close);
						dc.setTitle("Score Analysis");
						dc.setHeaderText("What You Messed Up:");
						Optional<ButtonType> response = dc.showAndWait();
					}
				});
				quit.setOnAction(new EventHandler<ActionEvent>() {
					@Override
					public void handle (ActionEvent event) {
						ImageView logo = new ImageView(new Image("file:///C:/Users/Public/Pictures/Moon.jpg"));
						logo.setFitWidth(128);
						logo.setPreserveRatio(true);
						System.out.println("\n\n\n\n\n\n\n\n\n\n==========================================================================================");
						System.out.println("New round started");
						scn = new Level(scrolls, data);
						altitude = 910;
						scn.setOnKeyPressed(new EventHandler<KeyEvent>() {
							@Override
							public void handle (KeyEvent event) {
								if (event.getCode().equals(KeyCode.W) && (lander.getFuel() > 0))
									wFlag = true;
								if (event.getCode().equals(KeyCode.A))
									aFlag = true;
								if (event.getCode().equals(KeyCode.D))
									dFlag = true;
								if (event.isShiftDown())
									shiftFlag = true;
							}
						});
						scn.setOnKeyReleased(new EventHandler<KeyEvent>() {
							@Override
							public void handle (KeyEvent event) {
								shiftFlag = false;
								if (event.getCode().equals(KeyCode.W))
									wFlag = false;
								if (event.getCode().equals(KeyCode.A))
									aFlag = false;
								if (event.getCode().equals(KeyCode.D))
									dFlag = false;
								if (event.isShiftDown())
									shiftFlag = false;
							}
						});
						stg.setScene(scn);
						keepGoing = true;
						new Thread(new Runnable() {
							@Override
							public void run () {
								System.out.println("Main game loop started for round: " + roundNum);
								runGameLoop();
								Platform.runLater(new Runnable() {
									@Override
									public void run () {
										gameEnder.fire();
									}
								});
							}
						}, "Main Game Loop").start();
					}
				});
				// cont.setOnAction(new EventHandler<ActionEvent>() {
				// @Override
				// public void handle (ActionEvent event) {
				// new Thread(initNewRound, "Prepare Next Round").start();
				// }
				// });
			}
		});
		new Thread(new Runnable() {
			@Override
			public void run () {
				System.out.println("Main game loop started for round: " + roundNum);
				startTime = System.currentTimeMillis();
				runGameLoop();
				new Thread(endGame, "End of round").start();
			}
		}, "Main Game Loop").start();
	}
	public static void main (String[] args) {
		Application.launch(args);
	}
	private void runGameLoop () {
		DecimalFormat scoreFormat = new DecimalFormat("0000");
		scoreLbl.setText("Score:   " + scoreFormat.format(score));
		roundStartTime = System.currentTimeMillis();
		// update the game repeatedly
		while (keepGoing) {
			if (!scn.getWindow().isShowing())
				System.exit(0);
			long durationMs = redraw();
			System.out.println(durationMs);
			// System.out.println(durationMs);
			if (durationMs == -1)
				return;
			try {
				Thread.sleep(Math.max(0, REFRESH_INTERVAL_MS - durationMs));
			} catch (InterruptedException e) {}
		}
	}
	private long redraw () {
		long t = System.currentTimeMillis();
		if (!updateModel())
			return -1;
		return System.currentTimeMillis() - t;
	}
	private boolean updateModel () {
		frameNum++;
		upFlag = false;
		downFlag = false;
		leftFlag = false;
		rightFlag = false;
		wrapLeft = false;
		wrapRight = false;
		if (bb.localToScene(bb.getLayoutBounds()).intersects(scrlUp.localToScene(scrlUp.getLayoutBounds())))
			upFlag = true;
		if (bb.localToScene(bb.getLayoutBounds()).intersects(scrlDown.localToScene(scrlDown.getLayoutBounds())))
			downFlag = true;
		if (bb.localToScene(bb.getLayoutBounds()).intersects(scrlLeft.localToScene(scrlLeft.getLayoutBounds()))) {
			leftFlag = true;
			double ll = Math.abs(bb.localToScene(bb.getLayoutBounds()).getMinX());
			double lg = Math.abs(ground.localToScene(ground.getLayoutBounds()).getMinX());
			if ((lg - ll) < 400)
				wrapLeft = true;
		}
		if (bb.localToScene(bb.getLayoutBounds()).intersects(scrlRight.localToScene(scrlRight.getLayoutBounds()))) {
			rightFlag = true;
			double ll = Math.abs(bb.localToScene(bb.getLayoutBounds()).getMaxX());
			double lg = Math.abs(ground.localToScene(ground.getLayoutBounds()).getMaxX());
			if ((lg - ll) < 400)
				wrapRight = true;
		}
		double newAngle = iv.getRotate();
		double newX = iv.getLayoutX();
		double newY = iv.getLayoutY();
		double groundX = ground.localToScene(ground.getLayoutBounds()).getMinX();
		double groundY = ground.localToScene(ground.getLayoutBounds()).getMinY();
		if (wFlag && (lander.getFuel() > 0)) // thrust
		{
			lander.setVerVel(lander.getVerVel() - (THRUST * Math.sin(Math.toRadians(90 + iv.getRotate()))));
			lander.setHorVel(lander.getHorVel() + (THRUST * Math.cos(Math.toRadians(90 - iv.getRotate()))));
			Random randy = new Random();
			int weird = randy.nextInt(4);
			if (weird == 1)
				landerImg.setImage(Lander.thrust1);
			else if (weird == 2)
				landerImg.setImage(Lander.thrust2);
			else if (weird == 3)
				landerImg.setImage(Lander.thrust3);
			else if (weird == 0)
				landerImg.setImage(Lander.thrust4);
			if ((frameNum % 4) == 0)
				lander.setFuel(lander.getFuel() - 1);
			DecimalFormat fuelFormat = new DecimalFormat("00");
			String fuel = "Fuel:    " + fuelFormat.format(lander.getFuel());
			fuelLbl.setText(fuel);
		}
		if (!wFlag || (lander.getFuel() == 0))
			landerImg.setImage(Lander.noThrust);
		if (aFlag) {
			if (shiftFlag)
				newAngle -= 0.35;
			else
				newAngle -= 3;
			newX += Math.cos(Math.toRadians(iv.getRotate())) - Math.cos(Math.toRadians(newAngle));
			newY += Math.sin(Math.toRadians(iv.getRotate())) - Math.sin(Math.toRadians(newAngle));
		}
		if (dFlag) {
			if (shiftFlag)
				newAngle += 0.35;
			else
				newAngle += 3;
			newX += Math.cos(Math.toRadians(iv.getRotate())) - Math.cos(Math.toRadians(newAngle));
			newY += Math.sin(Math.toRadians(iv.getRotate())) - Math.sin(Math.toRadians(newAngle));
		}
		lander.setVerVel(lander.getVerVel() + GRAVITY);
		if (newAngle < -90)
			newAngle = -90;
		if (newAngle > 90)
			newAngle = 90;
		newX += lander.getHorVel() / 60;
		newY += lander.getVerVel() / 60;
		altitude -= (newY - iv.getLayoutY());
		xPos += (newX - iv.getLayoutX());
		if (wrapLeft) {
			xPos -= 2560;
			groundX -= 2560;
		}
		if (wrapRight) {
			xPos += 2560;
			groundX += 2560;
		}
		if (upFlag && (lander.getVerVel() < 0)) {
			groundY -= newY - iv.getLayoutY();
			newY = iv.getLayoutY();
		}
		if (downFlag && (lander.getVerVel() > 0)) {
			groundY -= newY - iv.getLayoutY();
			newY = iv.getLayoutY();
		}
		if (leftFlag && (lander.getHorVel() < 0)) {
			groundX -= newX - iv.getLayoutX();
			newX = iv.getLayoutX();
		}
		if (rightFlag && (lander.getHorVel() > 0)) {
			groundX -= newX - iv.getLayoutX();
			newX = iv.getLayoutX();
		}
		iv.setRotate(newAngle);
		iv.relocate(newX, newY);
		ground.relocate(groundX, groundY);
		DecimalFormat df = new DecimalFormat("0000.00");
		DecimalFormat timeFormat = new DecimalFormat("00");
		long currentTime = System.currentTimeMillis();
		long elapsedTime = (currentTime - roundStartTime) + totalTime;
		int elapsedMinutes = (int)(elapsedTime / 60000);
		int elapsedSeconds = (int)((elapsedTime / 1000) - (elapsedMinutes * 60));
		String time = "Time:    " + timeFormat.format(elapsedMinutes) + ":" + timeFormat.format(elapsedSeconds);
		timeLbl.setText(time);
		DecimalFormat altFormat = new DecimalFormat("00000");
		String alt = "Altitude:      " + altFormat.format(altitude);
		altLbl.setText(alt);
		DecimalFormat speedFormat = new DecimalFormat("0000");
		DecimalFormat angleFormat = new DecimalFormat("00.00");
		String horVel = "Horizontal Speed:   " + speedFormat.format(lander.getHorVel());
		horVelLbl.setText(horVel);
		String verVel = "Vertical Speed:    " + speedFormat.format(lander.getVerVel());
		verVelLbl.setText(verVel);
		String ang = "Angle:           ";
		if (iv.getRotate() < 0)
			ang += angleFormat.format(iv.getRotate());
		else
			ang += " " + angleFormat.format(iv.getRotate());
		angleLbl.setText(ang);
		lander.setHorVel(lander.getHorVel() * HORIZONTAL_WIND_RESISTENCE);
		Task<Void> scoreLand = new Task<Void>() {
			@Override
			protected Void call () throws Exception {
				if (isCancelled())
					return null;
				Platform.runLater(new Runnable() {
					@Override
					public void run () {
						double scr = (0.5 * lander.getFuel()) + 100;
						double angle = Math.abs(iv.getRotate());
						double hVel = Math.abs(lander.getHorVel());
						double vVel = Math.abs(lander.getVerVel());
						System.out.println("Angle: " + landerData[2]);
						System.out.println("HVel: " + landerData[1]);
						System.out.println("VVel: " + landerData[0]);
						double sub = angle * 1.5 * hVel * 2 * lander.getVerVel();
						if ((angle > 7) && (angle < 11))
							scr *= 0.5;
						else if (angle >= 11)
							scr *= 0;
						if ((vVel > 10) && (vVel < 16))
							scr *= 0.5;
						else if (vVel >= 16)
							scr *= 0;
						if (hVel > 7.5)
							scr *= 0;
						if (scr == 0) {
							lander.setFuel(lander.getFuel() - (int)(Math.abs(iv.getRotate()) * 10));
							if (lander.getFuel() < 0)
								lander.setFuel(0);
						}
						score += scr;
					}
				});
				return null;
			};
		};
		landerData[0] = lander.getVerVel();
		landerData[1] = lander.getHorVel();
		landerData[2] = iv.getRotate();
		for (int x = 0; (x < 20) && (elapsedTime > 1000); x++)
			if (bb.localToScene(bb.getLayoutBounds()).intersects(zones[x].localToScene(zones[x].getLayoutBounds())) || bb.getLayoutBounds().intersects(zones[x].getLayoutBounds())) {
				totalTime = elapsedTime;
				new Thread(scoreLand, "Scoring").start();
				System.out.println("Success!");
				Task<Void> genSnap = new Task<Void>() {
					@Override
					public Void call () throws Exception {
						System.out.println("Landed on pad");
						Platform.runLater(new Runnable() {
							@Override
							public void run () {
								wi = scn.snapshot(wi);
							}
						});
						return null;
					}
				};
				new Thread(genSnap, "Gen snapshot").start();
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {}
				lander.setVerVel(0);
				lander.setHorVel(0);
				iv.setRotate(0);
				lander.setLanded(true);
				return false;
			}
		if (((frameNum % 6) == 0) && (elapsedTime > 1000)) {
			Thread makeShape = new Thread(new Runnable() {
				@Override
				public void run () {
					sh = Shape.intersect(bb, groundLine);
				}
			}, "Shape creation for ground detection");
			makeShape.start();
			try {
				makeShape.join();
			} catch (InterruptedException e) {}
			if ((sh.getBoundsInLocal().getWidth() != -1) && (sh.getBoundsInLocal().getHeight() != -1) && ((frameNum % 6) == 0)) {
				totalTime = elapsedTime;
				lander.setLanded(false);
				Task<Void> genSnap = new Task<Void>() {
					@Override
					public Void call () throws Exception {
						System.out.println("Hit ground");
						Platform.runLater(new Runnable() {
							@Override
							public void run () {
								wi = scn.snapshot(wi);
							}
						});
						return null;
					}
				};
				new Thread(genSnap, "Gen snapshot").start();
				return false;
			}
		}
		if ((altitude < 0.0) && (elapsedTime > 1000)) {
			totalTime = elapsedTime;
			lander.setLanded(false);
			Task<Void> genSnap = new Task<Void>() {
				@Override
				public Void call () throws Exception {
					System.out.println("hit alt 0");
					Platform.runLater(new Runnable() {
						@Override
						public void run () {
							wi = scn.snapshot(wi);
						}
					});
					return null;
				}
			};
			new Thread(genSnap, "Gen snapshot").start();
			return false;
		}
		return true;
		// resume();
	}
}
